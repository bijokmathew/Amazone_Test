import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeMap;

public  class StudentScore {
	
	public static Map<Integer, Double> getFinalScores( List<TestResult> resultList, double startDate, double endDate){
		
		if(null == resultList ){
			System.out.println("No results in the given date");
			System.exit(0);;
		}
		Map<Integer, Double> result = new HashMap();
        Collections.sort(resultList);

        int prevStudentId = resultList.get(0).getStudentId();
        ArrayList scores = new ArrayList();

        int len = 0;
        for (TestResult mTestResult : resultList) {
            len++;
            if (prevStudentId != mTestResult.getStudentId() || resultList.size() == len){
                result.put(prevStudentId, getAverageTopFiveScore(scores));
                prevStudentId = mTestResult.getStudentId();
                scores = new ArrayList();
                if(startDate < mTestResult.getTestDate() && mTestResult.getTestDate() < endDate){
                	scores.add(mTestResult.getTestScore());
                }
            }
            else {
            	if(startDate < mTestResult.getTestDate() && mTestResult.getTestDate() < endDate){
            		 scores.add(mTestResult.getTestScore());
            	}
               
            }
        }

        return result;
    }

    public static double getAverageTopFiveScore(ArrayList<Integer> topFiveScores) {
    	
    	if(0 == topFiveScores.size()){
    		System.out.println("No results in the given date");
    		System.exit(0);;
    	}
        Collections.sort(topFiveScores, Collections.reverseOrder());
        int sum = 0;
        int limit=0;
        
        limit = topFiveScores.size() > 5? 5:topFiveScores.size();
        
        for (int i = 0; i < limit; i++) {
            sum += topFiveScores.get(i);
        }
        return sum /limit;
    }

}
