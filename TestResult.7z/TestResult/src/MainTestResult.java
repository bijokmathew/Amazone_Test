import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MainTestResult {
	
	public static void main(String[] args) {
		
		Object [][] scores = new Object[][]{ { "11-02-2017", 1001, 78 }, {"11-03-2017", 1001, 89 }, {"21-02-2017", 1001, 97 },
				{"10-02-2015", 1001, 92 },{"10-2-2016", 1001, 99 }, { "11-03-2016", 1001, 66 }, {"22-03-2016", 1001, 23 },
				{ "11-02-2017", 1002, 78 }, {"10-03-2017", 1002, 89 },	{ "21-02-2017",1002, 87 }, 
				{ "02-02-2015", 1002, 92 }, {"10-02-2016", 1002, 98 }, { "11-03-2016", 1002, 76 }, { "22-03-2016", 1002, 23 } };

		List<TestResult> resultList = new ArrayList<>();
		Date date = new Date();
		long startDate =0;
		long endDate =0;
		
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		for (Object[] score : scores) {
			
			 
			    try {
					date = formatter.parse(score[0].toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    long dateInLong = date.getTime();
			    resultList.add(new TestResult( dateInLong, (int)score[1], (int)score[2]));
		}

		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter Start date in dd-mm-yyyy format:");
		try {
			startDate = formatter.parse((reader.next())).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Please enter Start date in correct format:");
			try {
				startDate = formatter.parse((reader.next())).getTime();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				System.out.println("Sorry entered date is not a correct format:");
				System.exit(0);
			}
			
		}		
		System.out.println("Enter End date in dd-mm-yyyy format:");
		try {
			endDate = formatter.parse((reader.next())).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Please enter End date in correct format:");
			try {
				endDate = formatter.parse((reader.next())).getTime();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				System.out.println("Sorry entered date is not a correct format:");
				System.exit(0);
			}
			
		}		
		System.out.println("Final Score:");
		System.out.println(StudentScore.getFinalScores(resultList, startDate, endDate) );
	}

}
