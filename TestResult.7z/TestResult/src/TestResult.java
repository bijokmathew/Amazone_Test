

public class TestResult implements Comparable<TestResult>{

	private int studentId; 
	private long testDate; 
	private int testScore; 
	
	public TestResult(long date, int id, int score){
		
		testDate = date;
		studentId = id;
		testScore = score;
	}
	
	public int getStudentId(){
		return studentId;
	}
	public long getTestDate(){
		return testDate;
	}
	public int getTestScore(){
		return testScore;
	}

	@Override
	 public int compareTo(TestResult mTestResult) {
        if (studentId > mTestResult.studentId)
            return 1;
        else if (studentId < mTestResult.studentId)
            return -1;
        else
            return 0;
	}
}
